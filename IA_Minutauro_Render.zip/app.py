from flask import Flask
import schedule
import time
import threading

app = Flask(__name__)

@app.route('/')
def home():
    return "IA Minutauro ejecutándose 24/7 en Render."

def tarea_periodica():
    print("Ejecutando tarea de IA...")

schedule.every(10).seconds.do(tarea_periodica)

def run_schedule():
    while True:
        schedule.run_pending()
        time.sleep(1)

if __name__ == "__main__":
    hilo = threading.Thread(target=run_schedule)
    hilo.start()
    app.run(host="0.0.0.0", port=10000)

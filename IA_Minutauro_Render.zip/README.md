# IA Minutauro

Este proyecto ejecuta una IA en Flask que realiza tareas periódicas usando `schedule`, diseñada para mantenerse activa 24/7 en Render.

## Archivos
- `app.py`: Código principal.
- `requirements.txt`: Dependencias.
- `Procfile`: Instrucción para iniciar en Render.

## Despliegue rápido
1. Sube este proyecto a un nuevo repositorio GitHub.
2. Conéctalo en [Render](https://dashboard.render.com).
3. Usa el plan gratuito con los siguientes comandos:

- Build command: `pip install -r requirements.txt`
- Start command: `python app.py`
